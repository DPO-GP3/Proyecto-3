package com.google.gson;

import java.io.Reader;

import P1.Pieza;

public class Gson {

	public Pieza[] fromJson(Reader reader, Class<Pieza[]> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
