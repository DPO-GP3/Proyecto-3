package interfaade;

import javax.swing.*;

public class PanelCentro extends JPanel {
    public PanelCentro() {
        JLabel label = new JLabel("Bienvenido al Sistema de Subastas");
        add(label);
    }
}